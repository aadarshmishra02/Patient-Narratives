# Data-extraction-and-text-analysis.
The objective of this assignment is to extract textual data articles from the given URL and perform text analysis to compute variables from url
